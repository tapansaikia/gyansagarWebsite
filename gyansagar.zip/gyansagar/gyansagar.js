

document.getElementById("reach").addEventListener('click',function(){
document.querySelector('#reachUs').scrollIntoView({ 
  behavior: 'smooth' 
});
});
document.getElementById("homebar").addEventListener('click',function(){
document.querySelector('#home').scrollIntoView({ 
  behavior: 'smooth' 
});
});
document.getElementById("about").addEventListener('click',function(){
document.querySelector('#aboutUs').scrollIntoView({ 
  behavior: 'smooth' 
});
});
document.getElementById("what").addEventListener('click',function(){
document.querySelector('#aboutUs').scrollIntoView({ 
  behavior: 'smooth' 
});
});



function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "navbar") {
        x.className += " responsive";
    } else {
        x.className = "navbar";
    }
}

 
